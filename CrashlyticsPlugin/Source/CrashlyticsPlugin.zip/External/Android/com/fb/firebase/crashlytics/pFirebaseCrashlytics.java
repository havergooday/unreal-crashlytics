package com.fb.firebase.crashlytics;

import com.google.firebase.crashlytics.FirebaseCrashlytics;
import android.app.NativeActivity;

public class pFirebaseCrashlytics {
	
	public pFirebaseCrashlytics(NativeActivity activity)
	{
		// Do nothing
	}

	public void setUserIdentifier(String userIdentifier) 
	{
		FirebaseCrashlytics.getInstance().setUserId(userIdentifier);
	}
}