package com.fb.firebase;

import com.fb.firebase.*;
import com.fb.firebase.crashlytics.*;
import android.app.NativeActivity;

public class pFirebase {
	
	private static boolean isInit = false;
	private static pFirebaseCrashlytics crashlytics = null;

	static public void initialize(NativeActivity activity)
	{
		if(!isInit)
		{
			isInit = true;
			crashlytics = new pFirebaseCrashlytics(activity);
		}
	}

	static public pFirebaseCrashlytics crashlyticsProxy()
	{
		return crashlytics;
	}
}
